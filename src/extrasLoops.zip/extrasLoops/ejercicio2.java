package extrasLoops;

public class ejercicio2 {

	public static void main(String[] args) {
	int	columna=10;
	int linea=4;
	
for (int i = 0; i < linea; i++) {
	for (int j = 0; j < columna; j++) {
		System.out.print("*");
	}
	System.out.println();
}
	}

}
/* **********
 * **********
 * **********
 * **********
 */




