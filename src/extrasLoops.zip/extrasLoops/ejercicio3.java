package extrasLoops;

import java.util.Scanner;

public class ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int num = 1;
		boolean isPrime = true;
		do {
			System.out.print("Enter a integer (positive) number: ");
			num = sc.nextInt();
		} while (num < 0);

		for (int i = 2; i < num ; i++) {
			if(num%i==0) {
				isPrime=false;
			}
		
	}
		if (isPrime) {
			System.out.println(num + " is prime");
		

		} else  {
			System.out.println(num + " no prime");
		}
		}
}



